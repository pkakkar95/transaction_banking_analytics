function parseData(createGraph){
	Papa.parse("train.csv",{
		download:true,
		complete:function(results){
			createGraph(results.data);
		}
    });
}
function createGraph(data){
	var Month=[];
	var Zuerich=["Transactions"];
	for(var i=1;i<data.length-1;i++){
		Month.push(data[i][0]);
		Zuerich.push(data[i][1]);
	}
	console.log(Month);
	console.log(Zuerich);
	var chart = c3.generate({
		bindto:'#chart',
		data: {
	        columns: [
	          Zuerich  
	        ]
	    },
	    axis: {
	        x: {
	            type: 'category',
	            categories: Month,
	            tick: {
	                multiline:false,
	            	culling: {
	                    max: 15 
	                }
	              
	            }
	        }
	    },
	    zoom: {
	        enabled: true
	    },
	    legend: {
	        position: 'right'
	    },
	    subchart: {
	        show: true
	    }
	    
	});
	
}
parseData(createGraph);